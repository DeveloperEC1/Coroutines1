package com.apps.coroutines

import kotlinx.coroutines.Deferred
import retrofit2.http.*

interface PartsApiClient {

    @GET("arpitmandliya/AndroidRestJSONExample/master/countries.json")
    fun getPartsAsync(): Deferred<retrofit2.Response<List<PartData>>>

    @POST("arpitmandliya/AndroidRestJSONExample/master/countries.json")
    fun addPartAsync(@Body newPart: PartData): Deferred<retrofit2.Response<Void>>

    @DELETE("arpitmandliya/AndroidRestJSONExample/master/countries.json/{id}")
    fun deletePartAsync(@Path("id") id: Int): Deferred<retrofit2.Response<Void>>

    @PUT("arpitmandliya/AndroidRestJSONExample/master/countries.json/{id}")
    fun updatePartAsync(@Path("id") id: Int, @Body newPart: PartData): Deferred<retrofit2.Response<Void>>
}
